package com.example.spring42;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface UserRepository extends CrudRepository<User, Integer> {
    @Query("SELECT p FROM User p WHERE CONCAT(p.name, ' ', p.surname, ' ', p.numberOfGroup) LIKE %?1%")
    List<User> search(String keyword);

}
