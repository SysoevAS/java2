package com.example.spring42;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping(path="/demo")
public class ControllerMain {
    @Autowired
    private UserRepository userRepository;
    @PostMapping(path="/add")
    public @ResponseBody String addNewUser(@RequestParam String name, @RequestParam String surname, @RequestParam Long numberOfGroup) {
        User n = new User();
        n.setName(name);
        n.setSurname(surname);
        n.setNumberOfGroup(numberOfGroup);
        userRepository.save(n);
        return "Saved";
    }
    @GetMapping(path="/all")
    public @ResponseBody Iterable<User> getAllUsers() {
        return userRepository.findAll();
    }
    @GetMapping(path="/")
    public String getAllUsers(Model model) {
        Iterable<User> users = userRepository.findAll();
        model.addAttribute("users", users);
        return "index";
    }
    @GetMapping(path="/add")
    public String showAddForm(Model model) {
        model.addAttribute("user", new User());
        return "add";
    }
    @DeleteMapping(path="/delete/{id}")
    public @ResponseBody String deleteUser(@PathVariable("id") Integer id) {
        userRepository.deleteById(id);
        return "Deleted";
    }
    @GetMapping(path="/edit/{id}")
    public String showEditForm(@PathVariable("id") Integer id, Model model) {
        User user = userRepository.findById(id).orElse(null);
        model.addAttribute("user", user);
        return "edit";
    }
    @PostMapping(path="/update/{id}")
    public String updateUser(@PathVariable("id") Integer id, @ModelAttribute User updatedUser) {
        User user = userRepository.findById(id).orElse(null);
        if (user != null) {
            user.setName(updatedUser.getName());
            user.setSurname(updatedUser.getSurname());
            user.setNumberOfGroup(updatedUser.getNumberOfGroup());
            userRepository.save(user);
        }
        return "redirect:/index";
    }
}
