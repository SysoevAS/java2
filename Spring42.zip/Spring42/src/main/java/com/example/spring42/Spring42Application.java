package com.example.spring42;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring42Application {

    public static void main(String[] args) {
        SpringApplication.run(Spring42Application.class, args);
    }
}
