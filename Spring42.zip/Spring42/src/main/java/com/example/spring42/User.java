package com.example.spring42;

import jakarta.persistence.*;

@Entity // This tells Hibernate to make a table out of this class
@Table(name = "User")
public class User {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer id;

    private String name;

    private String surname;
    private Long numberOfGroup;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }
    public Long getNumberOfGroup() {
        return numberOfGroup;
    }

    public void setNumberOfGroup(Long numberOfGroup) {
        this.numberOfGroup = numberOfGroup;
    }

    public String toString(){
        return "User = [id=" + id + ", name=" + name + ", surname=" + surname + ", number_of_group=" + numberOfGroup;
    }
}