package com.example.spring42;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring42ApplicationTests {

    @Test
    void contextLoads() {
    }

}
