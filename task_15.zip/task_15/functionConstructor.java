package task_15;

public abstract class functionConstructor {
    public abstract void calculateFunction();
}
