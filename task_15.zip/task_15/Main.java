package task_15;

public class Main {
    public static void main(String[] args) {
        linearFunction linear = new linearFunction();
        quadraticFunction quadratic = new quadraticFunction();

        linear.calculateFunction();
        quadratic.calculateFunction();
    }
}
